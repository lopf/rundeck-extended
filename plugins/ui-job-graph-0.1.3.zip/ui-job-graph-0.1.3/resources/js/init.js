jQuery(function () {
    if (typeof(RDPLUGIN) != 'object') {
        window.RDPLUGIN = {};
    }
    RDPLUGIN['job-graph'] = "ui-job-graph";
});